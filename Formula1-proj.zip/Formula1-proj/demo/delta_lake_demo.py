# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

drivers_df = spark.read.parquet(f"{processed_folder_path}/drivers") \
.withColumnRenamed("number", "driver_number") \
.withColumnRenamed("name", "driver_name") \
.withColumnRenamed("nationality", "driver_nationality") 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_demo
# MAGIC LOCATION "/FileStore/tables/demo"

# COMMAND ----------

drivers_df.write.format("delta").mode("overwrite").saveAsTable("f1_demo.drivers")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from f1_demo.drivers

# COMMAND ----------

drivers_df.write.format("delta").mode("overwrite").save("/FileStore/tables/demo/drivers_external")

# COMMAND ----------

df = spark.read.format("delta").load("/FileStore/tables/demo/drivers_external")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table f1_demo.drivers_external
# MAGIC using delta
# MAGIC location "/FileStore/tables/demo/drivers_external"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.drivers_external

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/user/hive/warehouse/

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended  f1_demo.drivers_external

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended  f1_demo.drivers

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS DemoDB

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create table DemoDB.drivers_external
# MAGIC using delta
# MAGIC location "/FileStore/tables/demo/drivers_external"

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended DemoDB.drivers_external

# COMMAND ----------

# MAGIC %sql
# MAGIC desc Database DemoDB

# COMMAND ----------

# MAGIC %sql
# MAGIC desc Database f1_demo

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/user/hive/warehouse/

# COMMAND ----------

# MAGIC %sql
# MAGIC show table extended in demodb like '*'

# COMMAND ----------

