# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races").filter("race_year=2019")

# COMMAND ----------

circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits")

# COMMAND ----------

print(races_df.count())
print(circuits_df.count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Inner Join

# COMMAND ----------

df_joined = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, "inner")#.select(races_df.name.alias("race_name"), circuits_df.name.alias("circuit_name"))

# COMMAND ----------

display(df_joined)

# COMMAND ----------

display(df_joined["name"])

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Left outer join
# MAGIC

# COMMAND ----------

df_joined = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, "left")#.select(races_df.name.alias("race_name"), circuits_df.name.alias("circuit_name"))
display(df_joined)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### right outer join
# MAGIC

# COMMAND ----------

df_joined = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, "right")#.select(races_df.name.alias("race_name"), circuits_df.name.alias("circuit_name"))
display(df_joined)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Semi Join
# MAGIC ###### inner join + only left columns

# COMMAND ----------

df_joined = races_df.join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, "semi")#.select(races_df.name.alias("race_name"), circuits_df.name.alias("circuit_name"))
display(df_joined)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Anti Join
# MAGIC ###### inverse(inner join) + only left columns

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

columns = races_df.schema.names
print(columns)
vals = [[1030,
21,
304,
"Abu Dhabi Grand Prix",
"2019-12-01T13:10:00.000+0000",
"2023-10-30T08:49:23.918+0000",
2019]]

# df = spark.createDataFrame(vals, columns)

newRow = spark.createDataFrame(vals,columns)
newRow.printSchema()
newRow = newRow.withColumn("race_timestamp",to_timestamp("race_timestamp"))
newRow = newRow.withColumn("ingestion_date",to_timestamp("ingestion_date"))
newRow = newRow.withColumn("race_id",newRow["race_id"].cast("int"))
newRow = newRow.withColumn("round",newRow["round"].cast("int"))
newRow = newRow.withColumn("circuit_id",newRow["circuit_id"].cast("int"))
newRow = newRow.withColumn("race_year",newRow["race_year"].cast("int"))
newRow.printSchema()
appended_df = races_df.union(newRow)
display(appended)

# COMMAND ----------

df_joined = appended_df.join(circuits_df, appended_df.circuit_id == circuits_df.circuit_id, "anti")#.select(races_df.name.alias("race_name"), circuits_df.name.alias("circuit_name"))
display(df_joined)

# COMMAND ----------

