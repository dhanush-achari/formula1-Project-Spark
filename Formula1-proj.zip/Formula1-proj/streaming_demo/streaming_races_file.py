# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

races_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                  StructField("year", IntegerType(), True),
                                  StructField("round", IntegerType(), True),
                                  StructField("circuitId", IntegerType(), True),
                                  StructField("name", StringType(), True),
                                  StructField("date", DateType(), True),
                                  StructField("time", StringType(), True),
                                  StructField("url", StringType(), True) 
])

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create DB 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_stream
# MAGIC LOCATION "/FileStore/tables/streaming_demo/stream_write"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Create a managed Table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_stream.races_transaction
# MAGIC (
# MAGIC   raceId INTEGER,
# MAGIC   year INTEGER,
# MAGIC   round INTEGER,
# MAGIC   circuitId INTEGER,
# MAGIC   name STRING,
# MAGIC   date DATE,
# MAGIC   time STRING,
# MAGIC   url STRING,
# MAGIC   createdDate DATE, 
# MAGIC   updatedDate DATE 
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC #### Streaming Read Setup

# COMMAND ----------

races_transaction_df = spark.readStream.format("csv").schema(races_schema).option("header",True).load("/FileStore/tables/streaming_demo/stream_read/")

# COMMAND ----------

display(races_transaction_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Streaming Write - Upsert Setup

# COMMAND ----------

# Function to upsert microBatchOutputDF into Delta table using merge
def upsertToDelta(microBatchOutputDF, batchId):
  # Set the dataframe to view name
  microBatchOutputDF.createOrReplaceTempView("v_races_transaction_update")

  # Use the view name to apply MERGE
  # NOTE: You have to use the SparkSession that has been used to define the `updates` dataframe

  # In Databricks Runtime 10.5 and below, you must use the following:
  # microBatchOutputDF._jdf.sparkSession().sql("""
  microBatchOutputDF.sparkSession.sql("""
    MERGE INTO f1_stream.races_transaction tgt
    USING v_races_transaction_update upd
    ON tgt.raceId = upd.raceId
    WHEN MATCHED THEN
    UPDATE SET tgt.raceId = upd.raceId,
                tgt.year = upd.year,
                tgt.round = upd.circuitId,
                tgt.name = upd.name,
                tgt.date = upd.date,
                tgt.time = upd.time,
                tgt.url = upd.url,
                tgt.updatedDate = current_timestamp
    WHEN NOT MATCHED
    THEN INSERT (raceId, year, round,name,date,time,url,createdDate ) VALUES (raceId, year, round,name,date,time,url, current_timestamp)
    """)

# Write the output of a streaming aggregation query into Delta table
(races_transaction_df.writeStream
  .format("delta")
  .foreachBatch(upsertToDelta)
  .outputMode("update")
  .option("checkpointLocation", "/FileStore/tables/streaming_demo/stream_checkpoint")
  .start()
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_stream.races_transaction

# COMMAND ----------

# MAGIC %md
# MAGIC #### Checking History - versioning - time travel

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_stream.races_transaction

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_stream.races_transaction@v1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_stream.races_transaction TIMESTAMP AS OF '2023-11-20T14:35:03.000+0000'