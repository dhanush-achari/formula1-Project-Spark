# Databricks notebook source
dbutils.fs.mkdirs("/FileStore/tables/streaming_demo/stream_checkpoint")
dbutils.fs.mkdirs("/FileStore/tables/streaming_demo/stream_read")
dbutils.fs.mkdirs("/FileStore/tables/streaming_demo/stream_write")

dbutils.fs.rm("/FileStore/tables/streaming_demo/stream_checkpoint",True)
dbutils.fs.rm("/FileStore/tables/streaming_demo/stream_read",True)
dbutils.fs.rm("/FileStore/tables/streaming_demo/stream_write",True)
