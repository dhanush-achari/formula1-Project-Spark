# Databricks notebook source
# MAGIC %fs
# MAGIC ls /FileStore/tables/raw

# COMMAND ----------

races_df = spark.read.options(header=True).csv("dbfs:/FileStore/tables/raw/races.csv")

# COMMAND ----------

races_renamed_df =races_df.withColumnRenamed("raceId","race_id")\
                            .withColumnRenamed("year","race_year")\
                            .withColumnRenamed("circuitId","circuit_id")       

# COMMAND ----------

display(races_renamed_df.date)

# COMMAND ----------

from pyspark.sql.functions import lit,concat,to_timestamp
races_timestamp_df = races_renamed_df.withColumn("race_timestamp",to_timestamp(concat(races_renamed_df.date,lit(" "),races_renamed_df.time)))

# COMMAND ----------

races_timestamp_df.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType
races_schema = StructType(fields = [StructField("race_id",IntegerType(),False),   # false since circuitId primary key
                                       StructField("race_year",StringType(),True),
                                       StructField("round",StringType(),True),
                                       StructField("circuit_id",StringType(),True),
                                       StructField("name",StringType(),True)
                                      ]
                             ) 

# COMMAND ----------

# MAGIC %md
# MAGIC ####Different style of specifying schema

# COMMAND ----------

races_timestamp_df = races_timestamp_df.withColumn("race_id",races_timestamp_df.race_id.cast(IntegerType()))\
                                        .withColumn("race_year",races_timestamp_df.race_year.cast(IntegerType()))\
                                        .withColumn("round",races_timestamp_df.round.cast(IntegerType()))\
                                        .withColumn("circuit_id",races_timestamp_df.circuit_id.cast(IntegerType()))

# COMMAND ----------

races_timestamp_df.show()

# COMMAND ----------

races_timestamp_df = races_timestamp_df[["race_id","race_year","round","circuit_id","name","race_timestamp"]]

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Dataframe writer API come with a method called partitionBy- Helps partition the data based on column provided so that reading becomes quicker next time we are doing any analysis basis the column specified. Usually partitionBy columns are date, year, week etc

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
races_final_df = races_timestamp_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

display(races_final_df)

# COMMAND ----------

races_final_df.write.mode("overwrite").partitionBy("race_year").parquet("/FileStore/tables/processed/races")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /FileStore/tables/processed/races

# COMMAND ----------

