# Databricks notebook source
# MAGIC %md
# MAGIC ## Step 1. Upload the circuits.csv file to the dbfs file store location in community edition
# MAGIC ## Step 2. Read the circuits.csv file using spark dataframe reader api 

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /FileStore/tables/raw/

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2. Read the circuits.csv file using spark dataframe reader api 

# COMMAND ----------

df =  spark.read.csv("dbfs:/FileStore/tables/raw/circuits.csv")

# COMMAND ----------

# display(df)
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setting the headers

# COMMAND ----------

circuits_df = spark.read.options(header=True).csv("dbfs:/FileStore/tables/raw/circuits.csv")
display(circuits_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Print Schema

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### InferSchema - not recommended

# COMMAND ----------

circuits_df = spark.read.options(header=True) \
.options(inferSchema=True) \
.csv("dbfs:/FileStore/tables/raw/circuits.csv")

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Specify schema

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType
circuits_schema = StructType(fields = [StructField("circuitId",IntegerType(),False),   # false since circuitId primary key
                                       StructField("circuitRef",StringType(),True),
                                       StructField("name",StringType(),True),
                                       StructField("location",StringType(),True),
                                       StructField("country",StringType(),True),
                                       StructField("lat",DoubleType(),True),
                                       StructField("lng",DoubleType(),True),
                                       StructField("alt",IntegerType(),True),
                                       StructField("url",StringType(),True),
                                      ]
                             ) 

# COMMAND ----------

circuits_df = spark.read \
              .options(header=True) \
                .schema( StructType(fields = [StructField("circuitId",IntegerType(),False),   # false since circuitId primary key
                                       StructField("circuitRef",StringType(),True),
                                       StructField("name",StringType(),True),
                                       StructField("location",StringType(),True),
                                       StructField("country",StringType(),True),
                                       StructField("lat",DoubleType(),True),
                                       StructField("lng",DoubleType(),True),
                                       StructField("alt",IntegerType(),True),
                                       StructField("url",StringType(),True),
                                      ]
                             ) ) \
                .csv("dbfs:/FileStore/tables/raw/circuits.csv")
            

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

circuits_df.describe().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Select only required columns - all different ways mentioned below

# COMMAND ----------

df=circuits_df.select("circuitId","circuitRef","name","location","country","lat","lng","alt")

df=circuits_df.select(circuits_df["circuitId"],circuits_df["circuitRef"],circuits_df["name"],circuits_df["location"],circuits_df["country"],circuits_df["lat"],circuits_df["lng"],circuits_df["alt"])

df=circuits_df.select(circuits_df.circuitId,circuits_df.circuitRef,circuits_df.name,circuits_df.location,circuits_df.country,circuits_df.lat,circuits_df.lng,circuits_df.alt)

from pyspark.sql.functions import col
df=circuits_df.select(col("circuitId"),col("circuitRef"),col("name"),col("location"),col("country"),col("lat"),col("lng"),col("alt"))

df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### To run sql on a spark df it has to be converted to temp view using createOrReplaceTempView

# COMMAND ----------

circuits_df.createTempView("circuits")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from circuits

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Rename column as required 

# COMMAND ----------

circuits_rename_df = df.withColumnRenamed("circuitId","circuit_id")\
                        .withColumnRenamed("circuitRef","circuit_ref")\
                        .withColumnRenamed("lat","latitude")\
                        .withColumnRenamed("lng","longitude")\
                        .withColumnRenamed("alt","altitude")
                                          

# COMMAND ----------

display(circuits_rename_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### adding a new column to dataframe - withColumn

# COMMAND ----------

from pyspark.sql.functions import current_timestamp  #current_timestamp() returns col object , only col object can be used in withColumn 
circuits_final_df = circuits_rename_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

display(circuits_final_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### if we need to insert a column with a single value the it has to converted to col object using lit()

# COMMAND ----------

from pyspark.sql.functions import lit
display(circuits_rename_df.withColumn("newcol",lit("new val")))

# COMMAND ----------

# MAGIC %md
# MAGIC #### store the data in parquet format in procesed layer

# COMMAND ----------

circuits_final_df.write.mode("overwrite").parquet("dbfs:/FileStore/tables/processed/circuits")

# COMMAND ----------

display(spark.read.parquet("dbfs:/FileStore/tables/processed/circuits"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### widgets
# MAGIC #### notebook workflows

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.notebook.help()

# COMMAND ----------

