# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingesting data

# COMMAND ----------

display(dbutils.fs.ls("/databricks-datasets/"))

# COMMAND ----------

display(dbutils.fs.ls("/"))

# COMMAND ----------

