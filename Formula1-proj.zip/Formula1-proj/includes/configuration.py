# Databricks notebook source
raw_folder_path = "/FileStore/tables/raw/"
processed_folder_path = "/FileStore/tables/processed/"
presentation_folder_path = "/FileStore/tables/presentation/"

# COMMAND ----------

